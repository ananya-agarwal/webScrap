import scrapy
from ..items import AmazonscraperItem

class AmazonSpider(scrapy.Spider):
    name = "amazon"
    page_number = 2
    start_urls = ["https://www.amazon.com/s?k=books&i=stripbooks-intl-ship&rh=n%3A283155%2Cp_n_publication_date%3A1250226011&dc&ds=v1%3ApjyvawUnKsVKdjDpauhPFBqpJBfFW7ggrh8gCadrGb4&crid=KHQVGNF0L67S&qid=1695447994&rnid=1250225011&sprefix=boo%2Cstripbooks-intl-ship%2C297&ref=sr_nr_p_n_publication_date_1"]

    def parse(self, response):
        items = AmazonscraperItem()

        product_name = response.css('.a-color-base.a-text-normal::text').extract()
        product_author = response.css('.a-color-secondary .a-row .a-size-base+ .a-size-base').css('::text').extract()
        product_price = response.css('.a-price-whole').css('::text').extract()
        product_imageLink = response.css('.s-image::attr(src)').extract()

        items['product_name'] = product_name
        items['product_author'] = product_author
        items['product_price'] = product_price
        items['product_imageLink'] = product_imageLink

        yield items

        next_page = 'https://www.amazon.com/s?k=books&i=stripbooks-intl-ship&rh=n%3A283155%2Cp_n_publication_date%3A1250226011&dc&' + str(AmazonSpider.page_number) + '&crid=KHQVGNF0L67S&qid=1695449366&rnid=1250225011&sprefix=boo%2Cstripbooks-intl-ship%2C297&ref=sr_pg_2'
        if AmazonSpider.page_number <= 75:
            AmazonSpider.page_number += 1
            yield response.follow(next_page, callback = self.parse)

    
